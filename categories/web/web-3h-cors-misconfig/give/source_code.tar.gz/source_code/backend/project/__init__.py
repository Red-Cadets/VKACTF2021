from flask import Flask
from flask_marshmallow import Marshmallow
from flask_restful import Api
from flask_cors import CORS

from project.models import db

app = Flask(__name__)
app.config.from_object('project.config.Config')

CORS(app, origins=app.config['FRONTEND_HOST'], supports_credentials=True)

api = Api(app)
ma = Marshmallow(app)

db.init_app(app)

from project import user, post, utils