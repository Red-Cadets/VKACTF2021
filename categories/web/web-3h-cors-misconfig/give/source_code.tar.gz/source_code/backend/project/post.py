from flask import request
from flask_restful import Resource

from project.utils import sanitize
from project.models import Post, User, db
from project import api, ma

class PostSchema(ma.Schema):
    class Meta:
        fields = ("id", "title", "content", "style")

post_schema = PostSchema()
posts_schema = PostSchema(many=True)

class PostListResource(Resource):
    def get(self, user_key):
        user = User.query.filter_by(key=user_key).first()
        return posts_schema.dump(user.posts)

    def post(self, user_key):
        user = User.query.filter_by(key=user_key).first()
        new_post = Post(
            title   = sanitize( request.json.get('title'),   500  ),
            content = sanitize( request.json.get('content'), 1500 ),
            style   = sanitize( request.json.get('style'),   500  ),
        )
        user.posts.append(new_post)
        db.session.add(user)
        db.session.add(new_post)
        db.session.commit()
        return post_schema.dump(new_post)

api.add_resource(PostListResource, '/posts/<string:user_key>')