from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class User(db.Model):
    __tablename__ = "users"
    user_id      = db.Column(db.Integer, primary_key=True)
    username     = db.Column(db.String(500), unique=True, nullable=False)
    password     = db.Column(db.String(500), nullable=False)
    posts        = db.relationship("Post", backref="User", lazy='dynamic')
    key          = db.Column(db.String(32), unique=True, nullable=False)
    view_request = db.Column(db.Boolean, default=False)

    def __repr__(self):
        return '<User %s>' % self.username

class Post(db.Model):
    __tablename__ = "posts"
    id      = db.Column(db.Integer, primary_key=True)
    title   = db.Column(db.String(500))
    content = db.Column(db.String(1500))
    style   = db.Column(db.String(500))

    user_id = db.Column(db.Integer, db.ForeignKey('users.user_id'))
    user    = db.relationship('User')

    def __repr__(self):
        return '<Post %s>' % self.id