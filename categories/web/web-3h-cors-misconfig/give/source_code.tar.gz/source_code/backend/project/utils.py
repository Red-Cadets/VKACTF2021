import os

from passlib.hash import bcrypt_sha256
from hashlib import md5
import requests

from project import app

def hash_password(plaintext):
    return bcrypt_sha256.hash(str(plaintext))

def verify_password(plaintext, ciphertext):
    return bcrypt_sha256.verify(plaintext, ciphertext)

def sanitize(field, size):
    return field[:size] if field else field

def generate_key():
    m = md5()
    m.update(os.urandom(100))
    return m.hexdigest()

def checkRecaptcha(token):
    data = {'secret':app.config['RECAPTCHA_SECRET'], 'response':token}
    response = requests.post('https://www.google.com/recaptcha/api/siteverify', data=data).json()
    return response['success']
