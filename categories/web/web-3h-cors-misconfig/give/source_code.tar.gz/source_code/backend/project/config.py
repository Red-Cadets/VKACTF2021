import os

basedir = os.path.abspath(os.path.dirname(__file__))
sqlite_url = "sqlite:///" + os.path.join(basedir, "users.db")

class Config:
    BASE_DIR = basedir

    SQLALCHEMY_DATABASE_URI = os.getenv("DATABASE_URL", sqlite_url)
    SQLALCHEMY_TRACK_MODIFICATIONS = False

    FRONTEND_HOST    = os.getenv("FRONTEND_URL")
    RECAPTCHA_SECRET = os.getenv("RECAPTCHA_SECRET")