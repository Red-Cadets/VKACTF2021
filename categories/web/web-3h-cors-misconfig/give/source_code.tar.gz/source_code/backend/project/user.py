from flask import request
from flask_restful import Resource

from project.utils import hash_password, verify_password, sanitize, generate_key, checkRecaptcha
from project.models import User, db
from project import api, app

class RegisterResource(Resource):
    def post(self):
        username = sanitize( request.json.get('username'), 500 )
        password = sanitize( request.json.get('password'), 500 )
        token    = request.json.get('recaptchaToken')
        if not checkRecaptcha(token):
            return {'error':'Captcha is invalid.'}
        user = User.query.filter_by(username=username).first()
        if user:
            return {'error':'Пользователь с таким именем уже существует'}
        key=generate_key()
        new_user = User(
            username=username,
            password=hash_password(password),
            key=key
        )
        db.session.add(new_user)
        db.session.commit()
        return '', 201

class LoginResource(Resource):
    def post(self):
        username = request.json.get('username')
        password = request.json.get('password')
        user = User.query.filter_by(username=username).first()

        if not user or not verify_password(password, user.password):
            return {'error':'Неверный логин или пароль'}

        return user.key, 200

class ShareResource(Resource):
    def post(self, user_key):
        user = User.query.filter_by(key=user_key).first()
        if user.view_request:
            return {'error':'Заметки ещё не просмотрены'}

        user.view_request = True
        db.session.add(user)
        db.session.commit()
        return '', 200


api.add_resource(RegisterResource, '/register')
api.add_resource(LoginResource, '/login')
api.add_resource(ShareResource, '/share/<string:user_key>')