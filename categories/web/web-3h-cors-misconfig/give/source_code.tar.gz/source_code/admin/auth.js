function auth(req, res, next) {
    if (!req.signedCookies.user) {
        var err = new Error("Недостаточно прав");
        err.status = 401;
        next(err);
    } else {
        if(req.signedCookies.user == 'admin'){
            next();
        } else {
            var err = new Error("Недостаточно прав");
            err.status = 401;
            next(err);
        }
    }
}

module.exports = auth;