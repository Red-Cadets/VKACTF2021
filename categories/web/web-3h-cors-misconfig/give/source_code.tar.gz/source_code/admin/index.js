const cookierParser = require('cookie-parser');
const express = require('express');
const cron    = require('node-cron');
const Pool    = require('pg').Pool;
const { exec } = require("child_process");
var cors = require('cors');

const visiter = require('./visiter');
const auth    = require('./auth');

const connectionString = process.env.DATABASE_URL
const pool = new Pool({
    connectionString,
})

const app = express()

const any_subdomain = new RegExp(`http:\/\/.*${process.env.MAIN_DOMAIN}$`)
var corsOptions = {
  origin: any_subdomain,
  credentials: true
}

app.use(cookierParser(process.env.KEY))
app.use(cors(corsOptions))

const URL = process.env.ADMIN_URL
const SECRET = process.env.SECRET

cron.schedule('* * * * *', async () => {
    console.log('Starting checker')
    await visiter.visit(URL, SECRET, pool)
})

app.use(auth)
app.get('/interestedNotes', function (req, res) {
    pool.query('SELECT key FROM users WHERE view_request = TRUE', (error, results) => {
        if (error) {
            throw error
        }
        var notes = '<h1>Интересные заметки:</h1>'
        for (let i = 0; i < results.rows.length; i++) {
            link = `${process.env.FRONTEND_URL}/posts/${results.rows[i]["key"]}`
            notes += `</br><a class="link" href="${link}">${link}</a></br>`
        }
        return res.status(200).send(notes)
    })
})

app.get('/iwantflag', function (req, res) {
    return res.send(`Flag: ${process.env.FLAG}`)
})

app.listen(5000, '0.0.0.0');