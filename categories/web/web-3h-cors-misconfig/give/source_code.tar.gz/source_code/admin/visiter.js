const puppeteer = require('puppeteer')


async function visit(url, secret, pool) {
    const browser = await puppeteer.launch({ executablePath: '/usr/bin/chromium', args: ['--no-sandbox'] })

    var page = await browser.newPage()
    await page.setCookie({
        name : 'user',
        value: secret,
        url: url
    })
    await page.goto(`${url}/interestedNotes`)
    await page.waitForSelector('.link', {
        "timeout": 5000,
    })
    var hrefs = await page.$$eval('.link', links => links.map(a => a.href))
    console.log(hrefs)
    await page.close()

    for (let i = 0; i < hrefs.length; i++) {
        var page = await browser.newPage()
        await page.setCookie({
            name: 'user',
            value: secret,
            url: url
        })
        console.log(`Check ${hrefs[i]}`)
        await page.goto(`${url}/interestedNotes`)
        await Promise.all([
            page.click(`a.link[href="${hrefs[i]}"]`),
            page.waitForNavigation()
        ]);
        var key = hrefs[i].split('/').slice(-1)[0]
        await pool.query(`UPDATE users SET view_request = FALSE WHERE key = '${key}'`)
    }
}

module.exports = { visit }