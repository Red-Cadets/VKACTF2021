import Vue from "vue";
import App from "./App.vue";
import router from "./router";
import store from "./store";
import axios from "axios";
import VueAxios from "vue-axios";

axios.defaults.withCredentials = true;
axios.defaults.baseURL = "https://api.beautiful-notes.ml";

axios.interceptors.response.use(undefined, function(error) {
    if (error) {
        const originalRequest = error.config;
        if (error.response.status === 401 && !originalRequest._retry) {
            originalRequest._retry = true;
            return router.push("/login");
        }
    }
});

Vue.config.productionTip = false;
Vue.use(VueAxios, axios);

new Vue({
    store,
    router,
    render: (h) => h(App),
}).$mount("#app");
