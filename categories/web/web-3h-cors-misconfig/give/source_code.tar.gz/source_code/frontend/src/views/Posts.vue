<template>
    <div>
        <div class="container">
            <div v-if="User">
                <h5 class="mt-3">
                    Привет, {{User}}
                </h5>
            </div>
            <div class="row justify-content-md-center">
                <div class="col-md-12 col-lg-8">
                    <h2>Добавить заметку</h2>
                    <form
                        class="rd-mailform text-left row row-narrow-10 row-10 contact-form"
                        data-form-output="form-output-global"
                        data-form-type="contact"
                        @submit.prevent="create">
                        <div class="col-lg-12">
                            <div class="form-wrap">
                                <input
                                    class="form-input"
                                    type="text"
                                    name="title"
                                    placeholder="Заголовок"
                                    v-model="form.title">
                            </div>
                        </div>
                        <div class="col-lg-12">
                            <div class="form-wrap">
                                <textarea
                                    class="form-input"
                                    name="content"
                                    v-model="form.content"
                                    placeholder="Описание...">
                                </textarea>
                            </div>
                        </div>
                        <!-- TODO: Добавить поле для описания своих стилей -->
                        <div class="form-button col-lg-12 text-right">
                            <button
                                class="button-block button button-dark-blue"
                                type="submit">
                                Добавить
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <section
            class="section section-md bg-default text-center"
            v-if="Posts">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-9 col-xl-7">
                        <h2>Мои Заметки</h2>
                        <div
                            class="card-group-custom card-group-corporate"
                            role="tablist"
                            aria-multiselectable="false">
                            <article
                                class="card card-custom card-corporate"
                                v-for="post in Posts.slice().reverse()"
                                :key="post.id">
                                <div class="card-header" role="tab">
                                    <div class="card-title">
                                        <a>{{post.title}}</a>
                                    </div>
                                </div>
                                <div class="collapse show">
                                    <div class="card-body">
                                        <p
                                            v-if="post.style"
                                            v-html="postWithStyles(post)">
                                        </p>
                                        <p v-else>
                                            {{post.content}}
                                        </p>
                                    </div>
                                </div>
                            </article>
                            <button
                                @click="share"
                                class="button-md button button-dark-blue"
                                type="submit">
                                Поделиться заметками с админом
                            </button>
                            <p
                                v-if="error"
                                class="mt-1"
                                id="error">
                                {{error}}
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
</template>

<script>
import { mapGetters } from "vuex";

export default {
    name: 'Posts',
    data() {
        return {
            form: {
                title: '',
                content: '',
            },
            error: null
        };
    },
    created: function () {
        // Получить все заметки
        this.axios.get(`posts/${this.Key}`)
            .then(response => {
                this.$store.commit("setPosts", response.data);
            })
    },
    computed: {
        ...mapGetters({Posts: "StatePosts", User: "StateUser", Key: "StateKey"}),
    },
    methods: {
        create() {
            // Добавить заметку
            this.axios.post(`posts/${this.Key}`, this.form)
                .then(response => {
                    this.$store.commit("addPost", response.data);
                })
        },
        postWithStyles(post) {
            return `<p style="${post.style}">${post.content}</p>`
        },
        share() {
            // Поделиться заметками
            this.axios.post(`share/${this.Key}`)
                .then(response => {
                    if (response.data.error) {
                        this.error = response.data.error
                    } else {
                        this.error = 'Запрос отправлен. Ожидайте . . .'
                    }
                })
        }
    }
};
</script>

<style>
  @import '../assets/css/style.css';
  @import '../assets/css/bootstrap.css';
</style>