<template>
    <section class="section section-md bg-default text-center">
        <div class="container">
            <div class="row justify-content-md-center">
                <div class="col-md-9 col-lg-7 col-xl-5">
                    <h3>Регистрация</h3>
                    <form
                        @submit.prevent="validate"
                        class="rd-form rd-mailform rd-form-centered">
                        <div class="form-wrap">
                            <input
                                class="form-input"
                                type="text"
                                name="username"
                                placeholder="Имя пользователя"
                                v-model="form.username">
                        </div>
                        <div class="form-wrap">
                            <input
                                class="form-input"
                                type="password"
                                name="password"
                                placeholder="Пароль"
                                v-model="form.password">
                        </div>
                        <div class="form-wrap">
                            <vue-recaptcha
                                ref="recaptcha"
                                size="invisible"
                                :sitekey="sitekey"
                                @verify="register"
                                @expired="onCaptchaExpired"
                            />
                        </div>
                        <button
                            class="button button-block button-primary"
                            type="submit">
                            Создать аккаунт
                        </button>
                    </form>
                    <p
                        v-if="error"
                        class="mt-1"
                        id="error">
                        {{error}}
                    </p>
                </div>
            </div>
        </div>
    </section>
</template>

<script>
import VueRecaptcha from 'vue-recaptcha';
export default {
    name: "Register",
    components: { VueRecaptcha },
    data() {
        return {
            form: {
                username: "",
                password: "",
            },
            error: null,
            sitekey: '6LcWr7oaAAAAAJLJAmDD8Ccn27bOUqy2JJ7TLyxr'
        };
    },
    methods: {
        register(recaptchaToken) {
            this.axios.post("register", {
                username: this.form.username,
                password: this.form.password,
                recaptchaToken: recaptchaToken
            })
            .then(response => {
                if (response.data.error) {
                    this.error = response.data.error
                } else {
                    this.error = null
                    this.$router.push("/login")
                }
            })
        },
        validate () {
            this.$refs.recaptcha.execute()
        },
        onCaptchaExpired () {
            this.$refs.recaptcha.reset()
        }
    },
};
</script>

<style>
  @import '../assets/css/style.css';
  @import '../assets/css/bootstrap.css';
</style>
