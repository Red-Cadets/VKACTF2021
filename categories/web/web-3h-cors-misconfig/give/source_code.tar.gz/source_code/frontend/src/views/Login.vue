<template>
    <section class="section section-md bg-default text-center">
        <div class="container">
            <div class="row justify-content-md-center">
                <div class="col-md-9 col-lg-7 col-xl-5">
                    <h3>Вход</h3>
                    <form @submit.prevent="login" class="rd-form rd-mailform rd-form-centered">
                        <div class="form-wrap">
                            <input
                                class="form-input"
                                type="text"
                                name="username"
                                placeholder="Имя пользователя"
                                v-model="form.username">
                        </div>
                        <div class="form-wrap">
                            <input
                                class="form-input"
                                type="password"
                                name="password"
                                placeholder="Пароль"
                                v-model="form.password">
                        </div>
                        <button
                            class="button button-block button-primary"
                            type="submit">
                            Войти
                        </button>
                    </form>
                    <p
                        v-if="error"
                        class="mt-1"
                        id="error">
                        {{error}}
                    </p>
                </div>
            </div>
        </div>
    </section>
</template>

<script>
export default {
    name: "Login",
    components: {},
    data() {
        return {
            form: {
                username: "",
                password: "",
            },
            error: null
        };
    },
    methods: {
        login() {
            this.axios.post("login", this.form)
                .then(response => {
                    if (response.data.error) {
                        this.error = response.data.error
                    } else {
                        this.error = null
                        this.$store.commit("setUser", this.form.username);
                        this.$store.commit("setKey", response.data);
                        this.$router.push("/posts");
                    }
                })
        }
    },
};
</script>

<style>
  @import '../assets/css/style.css';
  @import '../assets/css/bootstrap.css';
</style>
