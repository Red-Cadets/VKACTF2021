const state = {
    username: null,
    user_key: null,
    posts: null,
    error: null
};

const getters = {
    isAuthenticated: (state) => !!state.username,
    StatePosts: (state) => state.posts,
    StateUser: (state) => state.username,
    StateKey: (state) => state.user_key
};

const mutations = {
    setUser(state, username) {
        state.username = username;
    },
    setKey(state, key) {
        state.user_key = key;
    },
    setPosts(state, posts) {
        state.posts = posts;
    },
    addPost(state, post) {
        state.posts.push(post)
    },
    logout(state, user) {
        state.username = user
        state.user_key = user
        state.posts = user
    },
};

export default {
    state,
    getters,
    mutations,
};
