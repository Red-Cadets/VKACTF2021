<template>
    <div id="app" class="page">
        <NavBar />
        <router-view/>
    </div>
</template>
<script>

import NavBar from '@/components/NavBar.vue'
export default {
    components: {
        NavBar
    }
}
</script>
<style>
    #app {
        font-family: Avenir, Helvetica, Arial, sans-serif;
        -webkit-font-smoothing: antialiased;
        -moz-osx-font-smoothing: grayscale;
        text-align: center;
        color: #2c3e50;
    }
    @import 'assets/css/style.css';
    @import 'assets/css/bootstrap.css';
</style>
