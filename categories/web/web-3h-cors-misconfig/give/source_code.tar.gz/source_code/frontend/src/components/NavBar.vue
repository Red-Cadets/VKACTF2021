<template>
    <section class="breadcrumbs-custom bg-image context-dark">
        <div class="container">
            <h4 class="breadcrumbs-custom-title">Сервис для хранения заметок</h4>
            <ul class="breadcrumbs-custom-path">
                <li>
                    <span v-if="isLoggedIn">
                        <router-link to="/posts">Мои заметки</router-link> |
                        <a href="#" @click="logout">Выйти</a>
                    </span>
                    <span v-else>
                        <router-link to="/register">Зарегистрироваться</router-link>   |   
                        <router-link to="/login">Войти</router-link>
                    </span>
                </li>
            </ul>
        </div>
    </section>
</template>
<script>
export default {
    name: 'NavBar',
    computed : {
        isLoggedIn : function(){ return this.$store.getters.isAuthenticated}
    },
    methods: {
        logout (){
            this.$store.commit("logout", null)
            this.$router.push('/login')
        }
    },
}
</script>
<style>
  @import '../assets/css/style.css';
  @import '../assets/css/bootstrap.css';
</style>
