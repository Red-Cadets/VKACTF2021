<template>
    <section
        class="section section-md bg-default text-center"
        v-if="Posts">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-lg-9 col-xl-7">
                    <div
                        class="card-group-custom card-group-corporate"
                        role="tablist"
                        aria-multiselectable="false">
                        <article
                            class="card card-custom card-corporate"
                            v-for="post in Posts.slice().reverse()"
                            :key="post.id">
                            <div
                                class="card-header"
                                role="tab">
                                <div class="card-title">
                                    <a>{{post.title}}</a>
                                </div>
                            </div>
                            <div class="collapse show">
                                <div class="card-body">
                                    <p
                                        v-if="post.style"
                                        v-html="postWithStyles(post)">
                                    </p>
                                    <p v-else>
                                        {{post.content}}
                                    </p>
                                </div>
                            </div>
                        </article>
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>

<script>
import { mapGetters } from "vuex";

export default {
    name: 'Posts',
    created: function () {
        this.axios.get(`/posts/${this.$route.params.key}`)
            .then(response => {
                this.$store.commit("setPosts", response.data);
            })
    },
    computed: {
        ...mapGetters({Posts: "StatePosts"}),
    },
    methods: {
        postWithStyles(post) {
            return `<p style="${post.style}">${post.content}</p>`
        }
    }
};
</script>

<style scoped>
    @import '../assets/css/style.css';
    @import '../assets/css/bootstrap.css';
</style>